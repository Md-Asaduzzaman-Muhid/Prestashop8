/* homeslider.js */
